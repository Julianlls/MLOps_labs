# function
def func(x):
    return x + 1
