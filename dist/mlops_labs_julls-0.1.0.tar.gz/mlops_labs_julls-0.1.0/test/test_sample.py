# import sys
# sys.path += ['/users/julianlilas/desktop/mlops/mlops_labs/unit_testing_best_practice/src']

from unit_testing_best_practice.sample import *

# test code
def test_answer():
    assert func(4) == 5
